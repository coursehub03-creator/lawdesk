import 'package:flutter/material.dart';

import '../database/witness_db.dart';
import '../model/witness_model.dart';
import 'add_witness_screen.dart';

class WitnessScreen extends StatefulWidget {
  final int caseId;
  final String? firebaseCaseId;

  const WitnessScreen({
    super.key,
    required this.caseId,
    required this.firebaseCaseId,
  });

  @override
  State<WitnessScreen> createState() => _WitnessScreenState();
}

class _WitnessScreenState extends State<WitnessScreen> {
  List<WitnessModel> _witnesses = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);

    if (widget.firebaseCaseId == null || widget.firebaseCaseId!.isEmpty) {
      setState(() {
        _witnesses = const [];
        _loading = false;
      });
      return;
    }

    final list = await WitnessDB.getWitnessesByFirebaseCaseId(widget.firebaseCaseId!);
    setState(() {
      _witnesses = list;
      _loading = false;
    });
  }

  Future<void> _deleteLocal(int localId) async {
    await WitnessDB.deleteByLocalId(localId);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final hasCloudCase = widget.firebaseCaseId != null && widget.firebaseCaseId!.isNotEmpty;

    return Scaffold(
      appBar: AppBar(
        title: const Text('الشهود'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _load,
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: hasCloudCase
            ? () async {
                final added = await Navigator.push<bool>(
                  context,
                  MaterialPageRoute(
                    builder: (_) => AddWitnessScreen(
                      caseId: widget.caseId,
                      firebaseCaseId: widget.firebaseCaseId!,
                    ),
                  ),
                );
                if (added == true) {
                  await _load();
                }
              }
            : () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('لا يمكن إضافة شاهد قبل مزامنة القضية إلى السحابة.'),
                  ),
                );
              },
        child: const Icon(Icons.add),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : !hasCloudCase
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Text('هذه القضية غير متزامنة بعد. قم بمزامنة القضية أولاً ثم أضف الشهود.'),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.separated(
                    physics: const AlwaysScrollableScrollPhysics(),
                    itemCount: _witnesses.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, index) {
                      final w = _witnesses[index];
                      return ListTile(
                        title: Text(w.name),
                        subtitle: Text(w.role),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: w.localId == null ? null : () => _deleteLocal(w.localId!),
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}

import 'package:sqflite/sqflite.dart';
import 'db_helper.dart';
import '../model/verdict_model.dart';
import 'package:logger/logger.dart';

class VerdictDB {
  static final Logger _logger = Logger();

  static Future<void> createTable(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS verdicts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        firebase_id TEXT,
        session_id INTEGER,
        firebase_session_id TEXT,
        pdf_path TEXT,
        description TEXT,
        created_at TEXT,
        isSynced INTEGER DEFAULT 0,
        FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
      )
    ''');
  }

  static Future<int> insertVerdict(VerdictModel verdict) async {
    try {
      final db = await DBHelper.database;
      return await db.insert('verdicts', verdict.toMapLocal());
    } catch (e, stackTrace) {
      _logger.e('خطأ أثناء إدخال منطوق الحكم', error: e, stackTrace: stackTrace);
      return -1;
    }
  }

  static Future<List<VerdictModel>> getVerdictsBySessionId(int sessionId) async {
    final db = await DBHelper.database;
    final result = await db.query(
      'verdicts',
      where: 'session_id = ?',
      whereArgs: [sessionId],
    );
    return result.map((map) => VerdictModel.fromMapLocal(map)).toList();
  }

  static Future<void> deleteVerdictById(int id) async {
    final db = await DBHelper.database;
    await db.delete('verdicts', where: 'id = ?', whereArgs: [id]);
  }

  static Future<void> updateDescription(int id, String newDescription) async {
    final db = await DBHelper.database;
    await db.update(
      'verdicts',
      {'description': newDescription},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  /// ✅ تحديث المنطوق بعد رفعه إلى السحابة وربطه بـ firebaseId
  static Future<void> updateVerdictWithFirebaseId(int localId, VerdictModel verdict) async {
    final db = await DBHelper.database;
    await db.update(
      'verdicts',
      {
        'firebase_id': verdict.firebaseId,
        'isSynced': 1,
      },
      where: 'id = ?',
      whereArgs: [localId],
    );
  }

  static Future<List<VerdictModel>> getUnsyncedVerdicts() async {
    final db = await DBHelper.database;
    final result = await db.query('verdicts', where: 'isSynced = 0');
    return result.map((map) => VerdictModel.fromMapLocal(map)).toList();
  }

  static Future<void> markVerdictAsSynced(int localId) async {
    final db = await DBHelper.database;
    await db.update(
      'verdicts',
      {'isSynced': 1},
      where: 'id = ?',
      whereArgs: [localId],
    );
  }

  static Future<void> importVerdictIfNotExists(VerdictModel verdict) async {
    final db = await DBHelper.database;
    final result = await db.query(
      'verdicts',
      where: 'firebase_id = ?',
      whereArgs: [verdict.firebaseId],
    );

    if (result.isEmpty) {
      await db.insert('verdicts', verdict.toMapLocal());
    }
  }


/// ✅ جلب منطوقات الحكم حسب معرّف الجلسة السحابي (منع الخلط)
static Future<List<VerdictModel>> getVerdictsByFirebaseSessionId(String firebaseSessionId) async {
  final db = await DBHelper.database;
  final result = await db.query(
    'verdicts',
    where: 'firebase_session_id = ?',
    whereArgs: [firebaseSessionId],
    orderBy: 'created_at DESC',
  );
  return result.map((map) => VerdictModel.fromMapLocal(map)).toList();
}

/// تعليم السجل كمزامن بالاعتماد على firebase_id (احتياط)
static Future<void> markVerdictAsSyncedByFirebaseId(String firebaseId) async {
  final db = await DBHelper.database;
  await db.update(
    'verdicts',
    {'isSynced': 1},
    where: 'firebase_id = ?',
    whereArgs: [firebaseId],
  );
}

/// حذف سجل محلي بالاعتماد على firebase_id (احتياط)
static Future<int> deleteVerdictByFirebaseId(String firebaseId) async {
  final db = await DBHelper.database;
  return await db.delete('verdicts', where: 'firebase_id = ?', whereArgs: [firebaseId]);
}
}

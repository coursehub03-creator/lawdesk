import 'dart:io';

import 'package:logger/logger.dart';

import '../database/client_db.dart';
import '../database/cases_db.dart';
import '../database/sessions_db.dart';
import '../database/verdict_db.dart';
import '../database/evidence_db.dart';
import '../database/witness_db.dart';
import '../database/notification_db.dart';
import '../database/db_helper.dart';

import '../core/client_supabase_service.dart';
import '../core/case_supabase_service.dart';
import '../core/session_supabase_service.dart';
import '../core/verdict_supabase_service.dart';
import '../core/evidence_supabase_service.dart';
import '../core/evidence_storage_service.dart';
import '../core/witness_supabase_service.dart';

import '../model/client_model.dart';
import '../model/evidence_model.dart';
import '../model/witness_model.dart';

class SyncService {
  static final Logger _logger = Logger();

  static Future<void> syncAll() async {
    if (!await _hasInternet()) return;

    await _processPendingDeletes();

    await _syncClients();
    await _importClients();

    await _syncCases();
    await _importCases();

    await _syncSessions();
    await _importSessions();

    await _syncVerdicts();
    await _importVerdicts();

    await _syncEvidence();
    await _importEvidence();

    await _syncWitnesses();
    await _importWitnesses();

    await _syncNotifications();
    await _importNotifications();

    _logger.i('✅ تمت مزامنة جميع الكيانات.');
  }

  static Future<bool> _hasInternet() async {
    try {
      final result = await InternetAddress.lookup('example.com');
      return result.isNotEmpty && result[0].rawAddress.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  /// الحذف المعلّق (تم تسجيله عند الحذف بدون إنترنت)
  static Future<void> _processPendingDeletes() async {
    final db = await DBHelper.database;

    // ✅ Defensive: don't crash app startup if table doesn't exist yet.
    List<Map<String, Object?>> pending = const [];
    try {
      pending = await db.query(
        'pending_actions',
        where: 'action = ?',
        whereArgs: ['delete'],
      );
    } catch (e) {
      _logger.w('⚠️ pending_actions table missing or query failed: $e');
      return;
    }

    for (final action in pending) {
      final clientId = (action['client_id'] as String?)?.trim() ?? '';
      if (clientId.isEmpty) {
        // bad row - delete it to avoid infinite loop
        try {
          await db.delete('pending_actions', where: 'id = ?', whereArgs: [action['id']]);
        } catch (_) {}
        continue;
      }

      try {
        await ClientSupabaseService.deleteClient(clientId);
        await db.delete('pending_actions', where: 'id = ?', whereArgs: [action['id']]);
        _logger.i('☁️ تم تنفيذ الحذف المعلق للعميل id=$clientId');
      } catch (e) {
        _logger.w('⚠️ فشل تنفيذ الحذف المعلق id=$clientId: $e');
      }
    }
  }

  // === Clients ===

  static Future<void> syncClientUpdate(Client client) async {
    await ClientDB.updateClient(client.copyWith(isSynced: false));

    try {
      final updated = await ClientSupabaseService.pushUpdateToSupabase(client);
      if (updated != null && client.localId != null) {
        final clientWithLocal = updated.copyWith(localId: client.localId, isSynced: true);
        await ClientDB.updateClient(clientWithLocal);
        await ClientDB.markClientAsSynced(client.localId!);
        _logger.i('☁️ تم رفع وحفظ تعديل العميل (${client.id})');
      }
    } catch (e) {
      _logger.w('⚠️ استثناء أثناء رفع تعديل العميل (${client.id}): $e');
    }
  }

  static Future<void> _syncClients() async {
    final items = await ClientDB.getUnsyncedClients();
    for (final item in items) {
      try {
        if (item.id.isEmpty) {
          await ClientSupabaseService.pushInsertExistingLocal(item);
        } else {
          await syncClientUpdate(item);
        }
      } catch (e) {
        _logger.w('⚠️ فشل مزامنة العميل (localId=${item.localId}): $e');
      }
    }
  }

  static Future<void> _importClients() async {
    final items = await ClientSupabaseService.fetchClientsFromSupabase();
    for (final item in items) {
      await ClientDB.importClientIfNotExists(item);
    }
  }

  // === Cases ===
  static Future<void> _syncCases() async {
    final items = await CaseDB.getUnsyncedCases();
    for (final item in items) {
      final uploaded = await CaseSupabaseService.addCase(item);
      if (uploaded != null && item.localId != null) {
        await CaseDB.updateCase(uploaded.copyWith(localId: item.localId));
        await CaseDB.markCaseAsSynced(item.localId!);
      }
    }
  }

  static Future<void> _importCases() async {
    final items = await CaseSupabaseService.fetchCases();
    for (final item in items) {
      await CaseDB.importCaseIfNotExists(item);
    }
  }

  // === Sessions ===
  static Future<void> _syncSessions() async {
    final items = await SessionDB.getUnsyncedSessions();
    for (final item in items) {
      final saved = await SessionSupabaseService.addSession(item);
      if (saved.isSynced && item.localId != null) {
        await SessionDB.markSessionAsSynced(item.localId!);
      }
    }
  }

  static Future<void> _importSessions() async {
    final allCases = await CaseDB.getCases();
    for (final caseItem in allCases) {
      final firebaseCaseId = caseItem.firebaseId;
      final localCaseId = caseItem.localId ?? 0;
      if (localCaseId == 0) continue;

      if (firebaseCaseId != null && firebaseCaseId.trim().isNotEmpty) {
        final sessions = await SessionSupabaseService.fetchSessionsByCaseId(firebaseCaseId.trim());
        for (final session in sessions) {
          final corrected = session.copyWith(caseId: localCaseId, firebaseCaseId: firebaseCaseId.trim());
          await SessionDB.importSessionIfNotExists(corrected);
        }
      }
    }
  }

  // === Verdicts ===
  static Future<void> _syncVerdicts() async {
    final items = await VerdictDB.getUnsyncedVerdicts();
    for (final item in items) {
      await VerdictSupabaseService.addVerdict(item);
      if (item.localId != null) {
        await VerdictDB.markVerdictAsSynced(item.localId!);
      }
    }
  }

  static Future<void> _importVerdicts() async {
    final items = await VerdictSupabaseService.fetchVerdicts();
    for (final item in items) {
      await VerdictDB.importVerdictIfNotExists(item);
    }
  }

  // === Evidence ===
  static Future<void> _syncEvidence() async {
    final items = await EvidenceDB.getUnsyncedEvidence();
    for (final item in items) {
      try {
        final cloudCaseId = (item.firebaseCaseId ?? '').trim();
        final cloudId = (item.firebaseId ?? '').trim();
        if (cloudCaseId.isEmpty || cloudId.isEmpty || item.localId == null) {
          continue; // orphan or legacy
        }

        String filePath = item.filePath;

        // If we still have a local device file path, upload to Storage first.
        // Our EvidenceStorageService expects a File + firebaseCaseId (+ optional documentId).
        if (File(filePath).existsSync()) {
          final result = await EvidenceStorageService.uploadEvidenceFile(
            file: File(filePath),
            firebaseCaseId: cloudCaseId,
            // Keep storage folder stable and tied to evidence UUID.
            documentId: cloudId,
          );
          filePath = result.storagePath;
        }

        final toUpsert = item.copyWith(
          firebaseCaseId: cloudCaseId,
          firebaseId: cloudId,
          filePath: filePath,
        );

        final uploaded = await EvidenceSupabaseService.upsertEvidence(toUpsert);
        if (uploaded != null) {
          await EvidenceDB.updateEvidence(uploaded.copyWith(localId: item.localId, isSynced: true));
          await EvidenceDB.markEvidenceAsSynced(item.localId!);
        }
      } catch (e) {
        _logger.w('⚠️ فشل مزامنة الدليل (localId=${item.localId}): $e');
      }
    }
  }

  static Future<void> _importEvidence() async {
    final cases = await CaseDB.getCases();
    for (final c in cases) {
      final localCaseId = c.localId ?? 0;
      final cloudCaseId = (c.firebaseId ?? '').trim();
      if (localCaseId == 0 || cloudCaseId.isEmpty) continue;

      try {
        // Use the service's canonical method name (and keep an alias inside the service).
        final remote = await EvidenceSupabaseService.fetchEvidenceByCaseId(cloudCaseId);
        for (final ev in remote) {
          final corrected = ev.copyWith(caseId: localCaseId, firebaseCaseId: cloudCaseId);
          await EvidenceDB.importEvidenceIfNotExists(corrected);
        }
      } catch (e) {
        _logger.w('⚠️ فشل استيراد الأدلة للقضية $cloudCaseId: $e');
      }
    }
  }

  // === Witnesses ===
  static Future<void> _syncWitnesses() async {
    final items = await WitnessDB.getUnsyncedWitnesses();
    for (final item in items) {
      try {
        final cloudCaseId = (item.firebaseCaseId ?? '').trim();
        final cloudId = (item.firebaseId ?? '').trim();
        if (cloudCaseId.isEmpty || cloudId.isEmpty || item.localId == null) continue;

        // Upload to Supabase (service returns void). Then mark locally as synced.
        await WitnessSupabaseService.upsertWitness(item);
        await WitnessDB.markWitnessAsSynced(item.localId!);
      } catch (e) {
        _logger.w('⚠️ فشل مزامنة الشاهد (localId=${item.localId}): $e');
      }
    }
  }

  static Future<void> _importWitnesses() async {
    final cases = await CaseDB.getCases();
    for (final c in cases) {
      final localCaseId = c.localId ?? 0;
      final cloudCaseId = (c.firebaseId ?? '').trim();
      if (localCaseId == 0 || cloudCaseId.isEmpty) continue;

      try {
        final remote = await WitnessSupabaseService.fetchWitnessesByCaseId(cloudCaseId);
        for (final w in remote) {
          final corrected = w.copyWith(caseId: localCaseId, firebaseCaseId: cloudCaseId);
          await WitnessDB.importWitnessIfNotExists(corrected);
        }
      } catch (e) {
        _logger.w('⚠️ فشل استيراد الشهود للقضية $cloudCaseId: $e');
      }
    }
  }

  // === Notifications ===
  static Future<void> _syncNotifications() async {
    final items = await NotificationDB.getUnsyncedNotifications();
    for (final item in items) {
      await NotificationDB.markNotificationAsSynced(item.localId!);
    }
  }

  static Future<void> _importNotifications() async {}

  /// Sync + import only evidence.
  static Future<void> syncEvidenceOnly() async {
    await _syncEvidence();
    await _importEvidence();
  }

  /// Sync + import only witnesses.
  static Future<void> syncWitnessOnly() async {
    await _syncWitnesses();
    await _importWitnesses();
  }
}
